import json
import os
from flask import Flask, render_template, request, redirect, url_for, flash

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-key")
FILE_NAME = os.environ.get("CONTACTS_FILE", "contacts.json")


def load_contacts():
    try:
        with open(FILE_NAME, "r", encoding="utf-8") as file:
            return json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        return []


def save_contacts(contacts):
    with open(FILE_NAME, "w", encoding="utf-8") as file:
        json.dump(contacts, file, indent=4)


@app.route("/", methods=["GET"])
def home():
    contacts = load_contacts()
    query = request.args.get("q", "").strip()
    if query:
        contacts = [
            c for c in contacts
            if query.lower() in c.get("name", "").lower()
            or query in c.get("phone", "")
            or query.lower() in c.get("email", "").lower()
        ]
    return render_template("index.html", contacts=contacts, query=query,
                           total=len(load_contacts()))


@app.route("/add", methods=["POST"])
def add_contact():
    name = request.form.get("name", "").strip()
    phone = request.form.get("phone", "").strip()
    email = request.form.get("email", "").strip()

    if not name or not phone or not email:
        flash("Please fill in all three fields.", "error")
        return redirect(url_for("home"))

    contacts = load_contacts()
    contacts.append({"name": name, "phone": phone, "email": email})
    save_contacts(contacts)
    flash("Contact added successfully!", "success")
    return redirect(url_for("home"))


@app.route("/edit/<int:index>", methods=["POST"])
def edit_contact(index):
    contacts = load_contacts()
    if index < 0 or index >= len(contacts):
        flash("Contact not found.", "error")
        return redirect(url_for("home"))

    name = request.form.get("name", "").strip()
    phone = request.form.get("phone", "").strip()
    email = request.form.get("email", "").strip()
    if not name or not phone or not email:
        flash("Please fill in all three fields.", "error")
        return redirect(url_for("home"))

    contacts[index] = {"name": name, "phone": phone, "email": email}
    save_contacts(contacts)
    flash("Contact updated successfully!", "success")
    return redirect(url_for("home"))


@app.route("/delete/<int:index>", methods=["POST"])
def delete_contact(index):
    contacts = load_contacts()
    if index < 0 or index >= len(contacts):
        flash("Contact not found.", "error")
    else:
        contacts.pop(index)
        save_contacts(contacts)
        flash("Contact deleted successfully!", "success")
    return redirect(url_for("home"))


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=True)
