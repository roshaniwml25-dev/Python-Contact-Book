CONTACT BOOK - WEB APPLICATION

This project converts the original terminal-based Python Contact Book into a Flask website.

FEATURES
- Add contacts
- View saved contacts
- Search by name, phone number or email
- Edit contacts
- Delete contacts
- Save contact data in contacts.json

RUN LOCALLY (VS CODE)
1. Extract this ZIP folder.
2. Open the folder in VS Code.
3. Open Terminal > New Terminal.
4. Create and activate a virtual environment (optional but recommended):
   Windows: py -m venv venv
   Windows: venv\Scripts\activate
5. Install dependencies:
   pip install -r requirements.txt
6. Run:
   python app.py
7. Open this address in your browser:
   http://127.0.0.1:5000

DEPLOY TO RENDER
1. Upload the project folder to a GitHub repository.
2. Sign in to Render and choose New > Web Service.
3. Connect your GitHub repository.
4. Build command: pip install -r requirements.txt
5. Start command: gunicorn app:app
6. Deploy. Render will provide a public URL.

IMPORTANT
The included JSON file storage is suitable for a student demo. On many hosting platforms,
local files may not be permanent across redeploys or restarts. For long-term deployed use,
switch to a persistent disk or a database such as PostgreSQL.
